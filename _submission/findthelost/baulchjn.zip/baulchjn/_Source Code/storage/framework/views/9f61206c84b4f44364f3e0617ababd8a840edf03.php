<?php $__env->startSection('title', 'Add new item'); ?>

<?php $__env->startSection('content'); ?>
      <section id="pageTagline">
          <div class="thePageTagLine">
            Add new item
        </div>
    </section>
    <div class="container-fluid">
        <div class="row" style="">
            <div class="col-xl-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-heading-text"><img src="img/magnify.svg" width="35" height="35"/>Complete the form</div>
                    </div>

                    <div class="panel-body" class="openSans" style="font-size: 24px;">
                        <div class="panel-body-text">
                            <?php
                            //dd($errors);
                            ?>
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <p>* Denotes a required field</p>
                            <?php echo Form::open(['url' => '/add' , 'files' => true]); ?>

                            <div class="floatLeft" style="text-align: right;margin-right: 15px;">
                                <p><?php echo e(Form::label('category', 'Category*: ')); ?></p>
                                <p><?php echo e(Form::label('title', 'Brief title*: ')); ?></p>
                                <p><?php echo e(Form::label('description', 'Description*: ')); ?></p>
                                <p><?php echo e(Form::label('lostitem', 'Is it a lost item?*: ')); ?></p>
                                <p style="margin-top: 74px;">Location</p>
                                <p><?php echo e(Form::label('addressline1', 'Address Line 1*: ')); ?></p>
                                <p><?php echo e(Form::label('addressline2', 'Address Line 2: ')); ?></p>
                                <p><?php echo e(Form::label('addressline3', 'Address Line 3: ')); ?></p>
                                <p><?php echo e(Form::label('city', 'City*: ')); ?></p>
                                <p><?php echo e(Form::label('postcode', 'Postcode*: ')); ?></p>
                                <p><?php echo e(Form::label('photo', 'Image Upload*: ')); ?></p>
                            </div>
                            <div class="floatLeft">
                                <p><?php echo e(Form::select('category', ['pets' => 'Pets', 'electronics' => 'Electronics', 'jewellery' => 'Jewellery'], 'pets')); ?></p>
                                <p><?php echo e(Form::text('title')); ?></p>
                                <p><?php echo e(Form::text('description')); ?></p>
                                <p class="radio"><label><?php echo e(Form::radio('lostitem', 'I have lost this item', true)); ?>I have lost this item</label></p>
                                <p class="radio"><span class="secondRadio"><label><?php echo e(Form::radio('lostitem', 'I have found this item')); ?>I have found this item</label></span></p>
                                <div class="formSectionSeperator"></div>
                                <p><?php echo e(Form::text('addressline1')); ?></p>
                                <p><?php echo e(Form::text('addressline2')); ?></p>
                                <p><?php echo e(Form::text('addressline3')); ?></p>
                                <p><?php echo e(Form::text('city')); ?></p>
                                <p><?php echo e(Form::text('postcode')); ?></p>
                                <p><?php echo e(Form::file('photo')); ?></p>

                                <p><?php echo e(Form::submit('Submit')); ?></p>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>