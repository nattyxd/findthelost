<?php $__env->startSection('title', 'Manage Users'); ?>

<?php $__env->startSection('content'); ?>
      <section id="pageTagline">
          <div class="thePageTagLine">
            Manage Users
        </div>
    </section>    
    <div class="container-fluid">
        <div class="row" style="">
            <div class="col-xl-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-heading-text"><img src="../img/cog.svg" width="35" height="35"/>User Accounts</div>
                    </div>
                    <div class="panel-body" class="openSans">
                        <div class="panel-body-text">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p style="font-weight: bold;">(<?php echo e($user->id); ?>) <?php echo e($user->name); ?>

                                    <span style="font-weight: normal"> - <?php echo e($user->email); ?></span></p>
                                    <p>User level: 
                                    <?php if($user->userlevel == 1): ?>Administrator</p>
                                    
                                    <?php else: ?> User</p>
                                    <p>Trust level: <?php echo e($user->trust); ?></p>
                                    <?php
                                        $userItems = App\LostItem::where('user_id', '=', $user->id)->get();

                                        if ($userItems->count() > 0){
                                            foreach($userItems as $userItem){
                                                echo '<a href="../view/' . $userItem->id . '"><button type="button" class="btn btn-primary" style="margin-right: 15px;">View Item ' . $userItem->id . '</button></a>';
                                            }
                                        }
                                        else{ echo "<b>- This user has not yet added any items -</b>" ;}
                                    ?>
                                    <form method="POST" action="/admin/deleteuser/<?php echo e($user->id); ?>" style="margin-top: 15px;">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="submit" class="btn btn-danger" value="&#10007; Permanently Delete User" />
                                    </form>  
                                    <?php endif; ?>
                                    <hr/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php echo e($users->links()); ?>


                        </div>
                    </div>                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>