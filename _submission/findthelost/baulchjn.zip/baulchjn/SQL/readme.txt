This is an SQL dump from PhpMyAdmin using the export function.
It builds a schema of the database and dumps some example data.

Alternatively you can create the DB schema by executing "php artisan migrate" in terminal.