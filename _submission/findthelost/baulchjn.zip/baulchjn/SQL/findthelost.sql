-- phpMyAdmin SQL Dump
-- version 4.6.5
-- https://www.phpmyadmin.net/
--
-- Host: mysql.natbj.me
-- Generation Time: Mar 27, 2017 at 07:04 AM
-- Server version: 5.6.34-log
-- PHP Version: 7.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `findthelost`
--

-- --------------------------------------------------------

--
-- Table structure for table `item_requests`
--

CREATE TABLE `item_requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `lost_item_id` int(11) NOT NULL,
  `approved` tinyint(4) NOT NULL,
  `adminhandled` tinyint(4) NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `item_requests`
--

INSERT INTO `item_requests` (`id`, `created_at`, `updated_at`, `user_id`, `lost_item_id`, `approved`, `adminhandled`, `reason`, `image_url`) VALUES
(15, '2017-03-27 21:01:45', '2017-03-27 21:01:45', 18, 27, 0, 0, 'I lost it, the IMEI is 00000000 so you can tell it&#039;s mine', 'storage/lost_item_photos/R8tOmWPCRcQnC3v5iaSNLMp84evSoiLA551dUon6.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `lost_items`
--

CREATE TABLE `lost_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reunited` tinyint(1) NOT NULL,
  `lostitem` tinyint(1) NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addressline1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addressline2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addressline3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `approved` tinyint(4) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lost_items`
--

INSERT INTO `lost_items` (`id`, `category`, `title`, `description`, `reunited`, `lostitem`, `image_url`, `addressline1`, `addressline2`, `addressline3`, `city`, `postcode`, `created_at`, `updated_at`, `approved`, `user_id`) VALUES
(31, 'pets', 'Genuine Item - User gains trust', 'Accept the item to give the user + 100 trust', 0, 0, 'storage/lost_item_photos/MFZQ6Tg8eh1qtN9tbKvpwAVhsvX8nbdt0BQoQJUZ.jpeg', 'Test Street', '', '', 'Edinburgh', 'EH1 1HN', '2017-03-27 20:59:23', '2017-03-27 20:59:23', 0, 17),
(30, 'pets', 'Hack test!', 'This is an example spam item to be deleted', 0, 1, 'storage/lost_item_photos/UL1HUfsW27ujDAGIjmefQ0ExKc9WzB5Y1VoSMz2b.jpeg', '&lt;script&gt;alert(&#039;hack test&#039;);&lt;/script&gt;Hi', '&lt;script&gt;alert(&#039;hack test&#039;);&lt;/script&gt;Hi', '', '&lt;script&gt;alert(&#039;hack test&#039;);&lt;/script&gt;Hi', 'B1 1AA', '2017-03-27 20:57:17', '2017-03-27 20:57:17', 0, 17),
(28, 'jewellery', 'Diamond Ring', 'I lost it in London', 0, 1, 'storage/lost_item_photos/FqVn74U8k1bqkuSMMn6NCjnUh85H29yqm0VCOYru.jpeg', 'Buckingham Palace', '', '', 'London', 'SW1A 1AA', '2017-03-27 20:51:59', '2017-03-27 20:54:03', 1, 16),
(29, 'electronics', 'S7 Edge', 'It has a cracked screen: IMEI 00000000000', 0, 1, 'storage/lost_item_photos/eGa0qyjgq5tiN4oRPFkB9L08nQcNMfKHRUphsT8Q.jpeg', '1 Test Road', '', '', 'Manchester', 'M4 2AF', '2017-03-27 20:53:24', '2017-03-27 20:54:26', 1, 16),
(27, 'electronics', 'iPhone 7', 'I found this iPhone in the city centre', 0, 0, 'storage/lost_item_photos/aZUBZ2LvItNhTKz40VMyo2YBb24iUj2oV6B9MJK5.jpeg', '1 Colmore Row', '', '', 'Birmingham', 'B1 1AA', '2017-03-27 20:50:44', '2017-03-27 20:54:29', 1, 16);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_03_04_082948_create_lost_items_table', 1),
(4, '2017_03_04_143956_make_address_line_3_nullable', 1),
(5, '2017_03_09_141527_add_user_level_to_users_table', 1),
(6, '2017_03_11_011800_add_approved_to_lostitems_table', 2),
(7, '2017_03_15_221508_add_userid_to_lostitems_table', 3),
(8, '2017_03_15_224758_add_trust_column_to_users_table', 3),
(9, '2017_03_17_011117_create_requests_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `userlevel` tinyint(4) DEFAULT NULL,
  `trust` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `userlevel`, `trust`) VALUES
(18, 'Test 3', 'test3@test.com', '$2y$10$/2OBP5oIWw7SBysDWGlFL.ke10O5bfKHUmghalA7GXz5/XvlTvMRm', 'zX26mjJkS3ow7hmIyLDoEbvdlPAUJtmHq4dIv79G24EBhujUAQSJ7HsooEfA', '2017-03-27 21:00:26', '2017-03-27 21:00:26', NULL, 0),
(17, 'Test 2', 'test2@test.com', '$2y$10$7Zg.lW/JXQnAgy405ZJFzeCXHZMkJVuHN/HXuHfF7yEdxjPAhIYyG', '4wxm7fZXnd9MtM6jTmoEDNapHPaXqHTqPcQsLI44kDKCo8gxwht5PDXbRNoq', '2017-03-27 20:54:54', '2017-03-27 20:54:54', NULL, 0),
(16, 'Test User', 'test@test.com', '$2y$10$ZaeLQXr5yALtjvJPmjh4Qukpfemx4wttdhv0oCqJQ0ImhOljSajE6', '1BWBK1WAOGtlTSCni7208aJ5M48xKHP21FHALFL3xOj4dSWXctD3mhnV4uCo', '2017-03-27 17:32:49', '2017-03-27 20:54:29', NULL, 300),
(15, 'Regular User', 'regular@findthelost.club', '$2y$10$jd.VAcrh99jhVgLAKsHmuu0t4J/e4g4MBwlgV339hFnfnMoTcKF82', 'KfUdDYwURDHclSgCvQbFoqtqg4CzYcqOKPigzWqaQgyXTVXFoZePR6uCFqt9', '2017-03-25 16:24:41', '2017-03-27 20:54:15', NULL, 0),
(14, 'Administrator', 'admin@findthelost.club', '$2y$10$Ge7Op4Ri8idT.CbqRH9GRecJo56iJjdz6FU8PjPX/1WUOE9Hl8FQ2', 'k5NyFoxfSVBeLmrjEfYdRV3LDAwZO97WGyK4AJYnhQ7FKYjiiPLQ25zcWea3', '2017-03-25 16:09:15', '2017-03-25 16:09:15', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item_requests`
--
ALTER TABLE `item_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lost_items`
--
ALTER TABLE `lost_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`(250)),
  ADD KEY `password_resets_token_index` (`token`(250));

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item_requests`
--
ALTER TABLE `item_requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `lost_items`
--
ALTER TABLE `lost_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
